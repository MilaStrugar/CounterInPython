from django.apps import AppConfig


class CounterappConfig(AppConfig):
    name = 'counterApp'
